var searchData=
[
  ['buyformsubmited',['buyFormSubmited',['../classUserModule_1_1ApplicationPresenter.html#aa8f9d2ca88439bcf1321444b0db85ca0',1,'UserModule::ApplicationPresenter']]]
];
