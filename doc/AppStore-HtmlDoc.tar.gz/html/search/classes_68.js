var searchData=
[
  ['homepagepresenter',['HomepagePresenter',['../classAuthorModule_1_1HomepagePresenter.html',1,'AuthorModule']]],
  ['homepagepresenter',['HomepagePresenter',['../classHomepagePresenter.html',1,'']]],
  ['homepagepresenter',['HomepagePresenter',['../classUserModule_1_1HomepagePresenter.html',1,'UserModule']]],
  ['homepagepresenter',['HomepagePresenter',['../classAdminModule_1_1HomepagePresenter.html',1,'AdminModule']]]
];
