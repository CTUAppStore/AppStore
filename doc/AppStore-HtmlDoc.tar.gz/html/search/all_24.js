var searchData=
[
  ['_24connection',['$connection',['../classBaseRepository.html#afff8a645a0cf8786959fe0f4a654d22a',1,'BaseRepository']]],
  ['_24data',['$data',['../classUserModule_1_1ApplicationsCatalogGrid.html#a80d182c1c3b458d90a9873ca12d5a673',1,'UserModule\ApplicationsCatalogGrid\$data()'],['../classUserModule_1_1AuthorsCatalogGrid.html#af35c9404b7136475cb97fc055fd715ec',1,'UserModule\AuthorsCatalogGrid\$data()']]],
  ['_24repository',['$repository',['../classUserModule_1_1BasePresenter.html#a8e4a1155d9ac71e87c75f5e380de0a57',1,'UserModule::BasePresenter']]]
];
