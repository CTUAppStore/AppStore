var searchData=
[
  ['handlesignout',['handleSignOut',['../classUserModule_1_1SignedPresenter.html#a1e9c9e34921b2a307eb247fa35a6b643',1,'UserModule::SignedPresenter']]]
];
