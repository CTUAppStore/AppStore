var searchData=
[
  ['insertcomment',['insertComment',['../classApplicationRepository.html#a19132aadb082fad88947d6cc471ee11b',1,'ApplicationRepository']]],
  ['insertcommentformsubmitted',['insertCommentFormSubmitted',['../classUserModule_1_1ApplicationPresenter.html#a1cb5f41c5f875ca2404e21f5d1a53ba4',1,'UserModule::ApplicationPresenter']]]
];
