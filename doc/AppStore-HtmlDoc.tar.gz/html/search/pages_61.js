var searchData=
[
  ['appstore_20dokumentace',['AppStore Dokumentace',['../index.html',1,'']]]
];
