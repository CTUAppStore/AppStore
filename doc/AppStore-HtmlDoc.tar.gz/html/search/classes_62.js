var searchData=
[
  ['basepresenter',['BasePresenter',['../classAdminModule_1_1BasePresenter.html',1,'AdminModule']]],
  ['basepresenter',['BasePresenter',['../classUserModule_1_1BasePresenter.html',1,'UserModule']]],
  ['basepresenter',['BasePresenter',['../classAuthorModule_1_1BasePresenter.html',1,'AuthorModule']]],
  ['basepresenter',['BasePresenter',['../classBasePresenter.html',1,'']]],
  ['baserepository',['BaseRepository',['../classBaseRepository.html',1,'']]],
  ['boughtlicencespresenter',['BoughtLicencesPresenter',['../classUserModule_1_1BoughtLicencesPresenter.html',1,'UserModule']]]
];
